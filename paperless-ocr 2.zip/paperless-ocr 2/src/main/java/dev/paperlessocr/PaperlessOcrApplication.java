package dev.paperlessocr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaperlessOcrApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaperlessOcrApplication.class, args);
    }

}

package dev.paperlessocr.services.ocr;

public interface SearchIndexService {

    Result indexDocument(String d)
}
